from django.urls import path
from .models import vaccine, cases, labs, quarantine, sqliteseq, summery

urlpatterns = [
    path('cases/', cases.as_view(), name='cases'),
    path('labs/', labs.as_view(), name='labs'),
    path('quarantine/', quarantine.as_view(), name='quarantine'),
    path('sqliteseq/', sqliteseq.as_view(), name='sqliteseq'),
    path('summery/', summery.as_view(), name='summery'),
    path('vaccine/', vaccine.as_view(), name='vaccine'),
]