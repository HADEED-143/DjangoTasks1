import cases as cases
from django.shortcuts import render

from .models import cases, quarantine, sqliteseq, labs, vaccine, summery
from .serializers import casesSerializer, labsSerializer, quarantineSerializer, sqliteseqSerializer, vaccineSerializer, summerySerializer
from rest_framework.generics import ListAPIView
from django_filters.rest_framework import DjangoFilterBackend
# Create your views here.
from django.core.paginator import Paginator
class casesList(ListAPIView):
    queryset = cases.objects.all()
    serializer_class = casesSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id']

def cases(request, cases=None):
    cases = cases.objects.all()
    paginator = Paginator(cases, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request=request, context={'cases'})

class labList(ListAPIView):
    queryset = labs.objects.all()
    serializer_class = labsSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id']

class quarantine(ListAPIView):
    queryset = quarantine.objects.all()
    serializer_class = quarantineSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id']

class sqliteseq(ListAPIView):
    queryset = sqliteseq.objects.all()
    serializer_class = sqliteseqSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['name']

class summery(ListAPIView):
    queryset = summery.objects.all()
    serializer_class = summerySerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id']

class vaccine(ListAPIView):
    queryset = vaccine.objects.all()
    serializer_class = vaccineSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['id']